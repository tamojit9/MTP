package miner;

import java.util.HashMap;

import _stanfordParser.StanfordParserConfiguration;
import utilities.Configuration;

public class MinerConfiguration
{

	public static int G;
	public static int From;
	public static int To;
	public static String fileNameSuffix;
	public static HashMap<Integer, Integer> Thresholds;
	//static String domain;
	//static String numoflines;
	public static String Domain ;
	public static String getDomain() {
		return Domain;
	}
	public static void setDomain(String domain) {
		Domain = domain;
	}
	public static String getTotalSentences() {
		return TotalSentences;
	}
	public static void setTotalSentences(String totalSentences) {
		TotalSentences = totalSentences;
	}
	public static String TotalSentences ;
	public static String OtherSuffix = "";
	public static String ContestInputFileName;
	public static String StatsFileName;
	public static String CoverageStatsFileName;
	public static String PatternTriplesFileName;
	public static String FrequentPatternsFileName;
	public static String FrequentPatternsFilteredFileName;
	public static String GoodInstancesFileName;
	public static String NotCoveredSentencesFileName;
	public static String dropfile;
	public static String Invalidpatterns;
	public static String SymbolsAtLocatonFileName;
	public static void main(String args[]) throws Exception
	{
		//To = in.nextInt();
				//G = in.nextInt();
				From =3;
				To = 7;
				G=0;
				Domain=Configuration.Domain;
				TotalSentences=Configuration.NumberOfSentences;

				
				System.out.println("Enter the Thresholds for the various lengths, starting from : " + From);
				System.out.println(Domain);
				
				ContestInputFileName = ProjectPath + "data/validator and miner/input/Input" + TotalSentences + Domain
						+ OtherSuffix;
				StatsFileName = ProjectPath + "data/validator and miner/output/" + Domain + "/statistics/stats" + OtherSuffix;
				CoverageStatsFileName= ProjectPath + "data/validator and miner/output/" + Domain
						+ "/coverage statistics/coverageStats" + OtherSuffix + "-";
				PatternTriplesFileName = ProjectPath + "data/validator and miner/output/" + Domain
						+ "/frequent pattern triples/FPT" + OtherSuffix + "-";
				FrequentPatternsFileName= ProjectPath + "data/validator and miner/output/" + Domain
						+ "/frequent patterns/FP" + OtherSuffix + "-";
				FrequentPatternsFilteredFileName = ProjectPath + "data/validator and miner/output/" + Domain
						+ "/frequent patterns filtered/FP_Filtered" + OtherSuffix + "-";
				GoodInstancesFileName= ProjectPath + "data/validator and miner/output/" + Domain
						+ "/good instances/GoodInstances" + OtherSuffix + "-";
				NotCoveredSentencesFileName= ProjectPath + "data/validator and miner/output/" + Domain
						+ "/coverage statistics/SentenceWiseCoverage" + OtherSuffix + "-";
				dropfile= ProjectPath + "data/validator and miner/input/drop";
				Invalidpatterns = ProjectPath + "data/validator and miner/output/" + Domain
						+ "/Missing Patterns/MissingPatterns" + OtherSuffix + "-";
				SymbolsAtLocatonFileName=  ProjectPath + "data/validator and miner/output/" + Domain + "/SymbolsAtLocation/SymbolAtLocation"; 

				Thresholds = new HashMap<Integer, Integer>();

				for (int i = From; i <= To; i++)
				{
					Thresholds.put(i, 1);
				}

				if (From == To)
				{
					fileNameSuffix = "L =  " + From + " ,Th = " + Thresholds.toString();
				} else
				{
					fileNameSuffix = " From : L = " + From + " To L =  " + To + " ,Th = " + Thresholds.toString();
				}

				Parser.main(From, To, Thresholds, G, fileNameSuffix);
	}
	
	/* Input file name must be of the format 'InputTotalSentencesDomainOtherSuffix'. 
	 Examples : Input1582Legal, Input1144BiologyWithNP, Input1582LegalWithVP, etc.*/


	static String ProjectPath = Configuration.ProjectPath;
	 
}