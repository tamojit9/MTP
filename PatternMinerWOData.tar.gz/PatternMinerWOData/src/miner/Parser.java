package miner;

import testValidity.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.lang.instrument.Instrumentation;
public class Parser
{
	static int L, Th, G;
	static int FromLength, ToLength;
	static HashMap<Integer, Integer> Thresholds;

	static HashMap<String, Integer> tokenID;
	static ArrayList<String> tokenName;

	static ArrayList<Rule> rules;
	static ArrayList<ArrayList<Integer>> inverseMap;

	ArrayList<Sentences> sentences;
	HashMap<Integer, HashMap<Pattern, ArrayList<Triple>>> globalPatterns;
	
	// dump symbol at location
	static File symbolfp = new File(MinerConfiguration.SymbolsAtLocatonFileName);
	static PrintWriter symbolpw;

	public Parser() throws FileNotFoundException
	{
		tokenID = new HashMap<String, Integer>();
		tokenName = new ArrayList<String>();

		rules = new ArrayList<Rule>();
		inverseMap = new ArrayList<ArrayList<Integer>>();

		sentences = new ArrayList<Sentences>();
		globalPatterns = new HashMap<Integer, HashMap<Pattern, ArrayList<Triple>>>();
		
		symbolpw=new PrintWriter(symbolfp);
	}

	/* Assigns a unique token id to each token */
	static int getTokenID(String str)
	{
		if (!tokenID.containsKey(str))
		{
			tokenID.put(str, tokenID.size());
			tokenName.add(str);
			inverseMap.add(new ArrayList<Integer>());
		}
		return tokenID.get(str);
	}

	void printHMSAI(ArrayList<ArrayList<Integer>> hmsai)
	{
		println("Printing the hashmap ================ ");
		for (int i = 0; i < hmsai.size(); ++i)
		{
			print(tokenName.get(i) + " :: ");
			for (Integer j : hmsai.get(i))
			{
				print(j + " ");
			}
			print("\n");
		}
		println("==================");
	}

	/*
	 * Transforms the rules to objects of class Rule. Adds these objects to the
	 * list "rules" In the process, also generates the tokenIDs for the tokens
	 * in these rules.
	 */
	public void addRule(String dictStr)
	{
		String dictArr[] = dictStr.split("\\s*[-]+>\\s*");
		for (String rule : dictArr[1].split("\\s*[|]\\s*"))
		{
			Rule newRule = new Rule(dictArr[0], rule);
			inverseMap.get(newRule.rhs[0]).add(rules.size());
			rules.add(newRule);
		}
	}

	public void readInput(InputStream inStr) throws Exception
	{
		Scanner in = new Scanner(inStr);
		int num_sentences = in.nextInt();
		in.nextLine();

		for (int i = 0; i < num_sentences; i++)
			sentences.add(new Sentences((i + 1), in.nextLine()));

		int num_dict = in.nextInt();
		in.nextLine();
		for (int i = 0; i < num_dict; i++)
			addRule(in.nextLine());

		int num_gr = in.nextInt();
		System.out.println("num_gr :" +num_gr);
		in.nextLine();
		for (int i = 0; i < num_gr; i++)
			addRule(in.nextLine());

		// printHMSAI(inverseMap);
		in.close();
	}

	private void generatePatterns()
	{
		for (int i = 0; i < sentences.size(); i++)
		{
			System.out.println("Parsing Sentence : " + i);
			if(i%1000==0)System.out.println(Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory());
			sentences.get(i).parseSymbols(this);
			sentences.get(i).clear();
		}
	}

	private void printGlobalPatterns(PrintWriter fp_pw, PrintWriter fpt_pw)
	{
		for (int length : Thresholds.keySet())
		{
			HashMap<Pattern, ArrayList<Triple>> globalPatternsForCurentL = globalPatterns.get(length);
			for (Map.Entry<Pattern, ArrayList<Triple>> entry : globalPatternsForCurentL.entrySet())
			{
				if (entry.getValue().size() < Thresholds.get(length))
				{
					// println("Small");
					continue;
				}
				fp_pw.write(entry.getKey() + " : ");
				print(entry.getKey() + " : ");
				for (Triple t : entry.getValue())
				{
					fp_pw.write(t + " ");
					fpt_pw.write(entry.getKey() + " @");
					fpt_pw.write(t + "\n");
					print(t + " ");
				}
				fp_pw.write("\n");
				print("\n");
			}System.out.println("number of global pattern"+ globalPatternsForCurentL.size());

			HashMap<Pattern, HashSet<Triple>> patternsWithX = new HashMap<Pattern, HashSet<Triple>>();
			for (int mask = 1; mask < (1 << length); mask++)
			{
				patternsWithX.clear();
				if (!validMask(mask, Parser.G))
					continue;
				// println("Valid "+mask);
				for (Map.Entry<Pattern, ArrayList<Triple>> entry : globalPatternsForCurentL.entrySet())
				{
					Pattern newLS = entry.getKey().generate(mask);
					// println(entry.getKey()+" =("+""+")=> "+newLS);
					if (!patternsWithX.containsKey(newLS))
						patternsWithX.put(newLS, new HashSet<Triple>());
					HashSet<Triple> hashSet = patternsWithX.get(newLS);
					for (Triple triple : entry.getValue())
					{
						hashSet.add(triple);
					}
				}
				for (Map.Entry<Pattern, HashSet<Triple>> entry : patternsWithX.entrySet())
				{
					if (entry.getValue().size() < Thresholds.get(length))
						continue;
					fp_pw.write(entry.getKey() + " : ");
					print(entry.getKey() + " : ");
					for (Triple t : entry.getValue())
					{
						fp_pw.write(t + " ");
						fpt_pw.write(entry.getKey() + " @");
						fpt_pw.write(t + "\n");
						print(t + " ");
					}
					fp_pw.write("\n");
					print("\n");
				}
			}
		}
	}

	private boolean validMask(int mask, int g)
	{
		int numCont = 0;
		while (mask > 0)
		{
			int bit = mask % 2;
			mask /= 2;
			if (bit == 1)
				numCont++;
			else
				numCont = 0;
			if (numCont > g)
				return false;
		}
		return true;
	}

	public void addPattern(int length, Pattern newPattern, Triple triple)
	{
		if (!globalPatterns.containsKey(length))
		{
			HashMap<Pattern, ArrayList<Triple>> globalPatternsForCurentL = new HashMap<Pattern, ArrayList<Triple>>();
			globalPatterns.put(length, globalPatternsForCurentL);
		}
		{
			HashMap<Pattern, ArrayList<Triple>> globalPatternsForCurentL = globalPatterns.get(length);
			if (!globalPatternsForCurentL.containsKey(newPattern))
			{
				globalPatternsForCurentL.put(newPattern, new ArrayList<Triple>());
			}
			globalPatternsForCurentL.get(newPattern).add(triple);
		}
	}

	public static void println(Object obj)
	{
		// System.out.println(obj);
	}

	public static void print(Object obj)
	{
		// System.out.print(obj);
	}

	public static void main(int fromLength, int toLength, HashMap<Integer, Integer> ThresholdMap, int Gap,
			String fileNameSuffix) throws Exception
	{
		long start = System.currentTimeMillis();
		FromLength = fromLength;
		ToLength = toLength;
		Thresholds = new HashMap<Integer, Integer>(ThresholdMap);
		G = Gap;
		System.out.println(MinerConfiguration.Domain);
		File fp = new File(MinerConfiguration.FrequentPatternsFileName + fileNameSuffix);
		File fpt = new File(MinerConfiguration.PatternTriplesFileName + fileNameSuffix);
		PrintWriter fp_pw = new PrintWriter(fp);
		PrintWriter fpt_pw = new PrintWriter(fpt);

		Parser p = new Parser();
		getTokenID("_X_");

		p.readInput(new FileInputStream(MinerConfiguration.ContestInputFileName));
		p.generatePatterns();
		p.printGlobalPatterns(fp_pw, fpt_pw);
		System.out.println("done writing ....");
		
		long end = System.currentTimeMillis();
		System.out.println("Time for pattern generation : " + (end - start) / 1000.0 + " seconds. ");
		fp_pw.close();
		fpt_pw.close();
		symbolpw.close();
		//System.out.println();
		ValidatePatterns validateObj = new ValidatePatterns(Thresholds, p.sentences.size(), fileNameSuffix);
		validateObj.validate();
	}

	/*
	 * public static void main(String args[]) throws Exception { long start =
	 * System.currentTimeMillis(); getTokenID("_X_"); Parser p = new Parser();
	 * 
	 * Scanner in = new Scanner(System.in); L = in.nextInt(); Th = in.nextInt();
	 * G = in.nextInt(); int ThForLengthOne = in.nextInt(); File fp = new
	 * File(Configuration.frequentPatternsFileName + L + "-" + Th); File fpt =
	 * new File(Configuration.patternTriplesFileName + L + "-" + Th);
	 * ValidatePatterns validateObj = new ValidatePatterns(L, Th,
	 * ThForLengthOne);
	 * 
	 * if (fp.exists() && fpt.exists()) { validateObj.validate(); } else {
	 * PrintWriter fp_pw = new PrintWriter(fp); PrintWriter fpt_pw = new
	 * PrintWriter(fpt); if (args.length != 0) p.readInput(new
	 * FileInputStream(args[0])); else p.readInput(new
	 * FileInputStream(Configuration.contestInputFileName));
	 * p.generatePatterns(); p.printGlobalPatterns(fp_pw, fpt_pw); long end =
	 * System.currentTimeMillis(); fp_pw.close(); fpt_pw.close();
	 * //System.out.println("Time for pattern generation : " + (end - start) /
	 * 1000.0 + " seconds. "); validateObj.validate(); } }
	 */
}