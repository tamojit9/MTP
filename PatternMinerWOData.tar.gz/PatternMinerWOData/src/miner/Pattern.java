package miner;

import java.util.Arrays;

class Pattern
{
	int[] symbols;

	public Pattern(int length)
	{
		symbols = new int[length];
	}

	public boolean equals(Object obj)
	{
		return Arrays.equals(((Pattern) obj).symbols, symbols);
	}

	public int hashCode()
	{
		return Arrays.hashCode(symbols);
	}

	public Pattern addLS(Pattern ls)
	{
		Pattern newLS = new Pattern(symbols.length + ls.symbols.length);
		for (int i = 0; i < symbols.length; ++i)
			newLS.symbols[i] = symbols[i];
		for (int i = 0; i < ls.symbols.length; ++i)
			newLS.symbols[i + symbols.length] = ls.symbols[i];
		return newLS;
	}

	public int get(int index)
	{
		return symbols[index];
	}

	public String toString()
	{
		String ret = new String("");
		for (int s : symbols)
			ret += Parser.tokenName.get(s) + " ";

		return ret.equals("") ? ret : ret.substring(0, ret.length() - 1);
	}

	/* Generates a pattern for the given mask */
	public Pattern generate(int mask)
	{
		Pattern ret = new Pattern(symbols.length);
		for (int i = 0; i < symbols.length; i++)
			ret.symbols[i] = (mask & (1 << i)) == 0 ? symbols[i] : 0;
		return ret;
	}
}