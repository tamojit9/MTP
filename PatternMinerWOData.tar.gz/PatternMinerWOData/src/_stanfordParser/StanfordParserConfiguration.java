


package _stanfordParser;

import utilities.Configuration;

public class StanfordParserConfiguration
{
	public static String Domain = Configuration.Domain;
	public static String NumberOfSentences = Configuration.NumberOfSentences;
	public static boolean DeserializeFromFile = false;
	/* false : serialize, true : deserialize */

	public static String ProjectPath = Configuration.ProjectPath;
	public static String InputFileName = ProjectPath + "data/stanford parser/input/Input" + NumberOfSentences + Domain;
	public static String OutputFileName = ProjectPath + "data/stanford parser/output/rules/rules_"+Domain+"_" + NumberOfSentences;
	public static String PhraseType = "VP";
	public static String SerializationFileName = ProjectPath + "data/stanford parser/output/serialized parses/Parser"
			+ NumberOfSentences + Domain + ".ser";
}