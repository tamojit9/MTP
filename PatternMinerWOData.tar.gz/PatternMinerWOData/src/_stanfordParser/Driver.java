

package _stanfordParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import cleaning.RemoveFW;
import edu.stanford.nlp.trees.Tree;

public class Driver
{
	public static void main(String args[]) throws IOException
	{
		long start = System.currentTimeMillis();
		Document document = new Document(StanfordParserConfiguration.InputFileName,
				StanfordParserConfiguration.SerializationFileName);
		/* false : serialize, true : deserialize */
		document.synthesizeDocument(StanfordParserConfiguration.DeserializeFromFile);
		System.out.println("Parsing is done or Loaded .............\n\n\n\n");
		/* For writing the rules to the file */
		Parser p = new Parser();
		List<List<Tree>> rhsLists = new ArrayList<List<Tree>>();

		for (Sentence currentSentence : document.sentences)
		{
			List<Tree> rhs = p.getPhrases(StanfordParserConfiguration.PhraseType, currentSentence.parseTree);
			rhsLists.add(rhs);
		}

		PrintingUtilities.PrintRules(StanfordParserConfiguration.PhraseType, rhsLists);

		long end = System.currentTimeMillis();
		System.out.println("Generation of Production Rules done in " + (end - start) / 1000.0 + " seconds.");

		RemoveFW.remove(); // Remove the Functional Words from the beginning and
							// start of the rules.
	}
}