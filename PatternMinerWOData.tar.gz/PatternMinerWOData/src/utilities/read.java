package utilities;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class read {
	
	static int line_no = 1;
	
	public static void main(String[] args) throws FileNotFoundException {
		String file="englishText_0_10000.utf8.txt";
		String filename="/home/vishwajeet/workspace_ontolearn/PatternMiner/data/wiki/"+file;
		processFile(filename);
		
	}
	public static void processFile(String filename) throws FileNotFoundException
	{
		PrintWriter pw = new PrintWriter(new File("/home/vishwajeet/workspace_ontolearn/PatternMiner/data/wiki/InputWiki"));
		Scanner scn;
		try {
			scn = new Scanner(new File(filename));
			
			while(scn.hasNextLine()){
				String line = scn.nextLine();
				process(line,pw);
			}
			pw.close();
			scn.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void process(String line,PrintWriter pw) {
		
		//System.out.println(line);
		
		if(line.isEmpty())
			return;
		
		if(line.charAt(0) == '<' || line.charAt(0) == ';')
			return;
		
		if(line == line.toUpperCase())
			return;
		
		String lines[] = line.split("\\.");
		
		for(String l : lines){
			pw.write(line_no+"- "+l.trim()+".");
			pw.write("\n");
			System.out.println(line_no+"- "+l.trim()+".");
				line_no++;
		}
	}

}

