package utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.ling.Sentence;
import edu.stanford.nlp.process.DocumentPreprocessor;

public class GetParams {

	public int maxlength = 0;
	public static String corpus_file = Configuration.CorpusFile;
	public static int length = 0;

	public static int GetMaxLength(String corpus_file) throws FileNotFoundException {
		processFile(corpus_file);

		return length;
	}

	public static void processFile(String str) throws FileNotFoundException {
		Scanner scn;
		ArrayList<String> lines = new ArrayList<String>();
		try {
			scn = new Scanner(new File(str));
			

			while (scn.hasNextLine()) {

				String line = scn.nextLine();
				//System.out.println(line);
				lines.add(line);
			}

			System.out.println("final length is:" + length);

			scn.close();
			

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(lines.size());
		process(lines);
	}

	static int line_no = 1;

	public static void main(String[] args) throws FileNotFoundException {

		//processFile(corpus_file);
		getSentences();

	}
	
	
	

	private static void process(ArrayList<String> lineslist) throws FileNotFoundException {

		System.out.println(lineslist.size());
		File cleanedsentfile = new File(Configuration.ProjectPath + "temp");
		PrintWriter pw = new PrintWriter(cleanedsentfile);

		for (String line : lineslist) {
			System.out.println(line);
			if (line.isEmpty())
				continue;

			if (line.charAt(0) == '<' || line.charAt(0) == ';')
				continue;

			if (line == line.toUpperCase())
				continue;

			String lines[] = getSentences(line);
			pw.write(line.length());
			pw.write("\n");

			for (String l : lines) {
				System.out.println(line_no + "-" + l + ".");
				pw.write(line_no + "-" + l + ".");
				pw.write("\n");
				line_no++;
				int temp_length = 0;
				temp_length = l.split(" ").length;
				if (temp_length > length) {
					length = temp_length;
				}
				System.out.println("current length is:" + temp_length);
			}
			

		}
		pw.close();
	}

	private static List<String> getSentences() throws FileNotFoundException {
		PrintWriter pw=new PrintWriter("/home/vishwajeet/merged_sentences_2000.txt");
		
		DocumentPreprocessor dp = new DocumentPreprocessor(Configuration.CorpusFile);
		List<String> sentenceList = new ArrayList<String>();

		for (List<HasWord> sentence : dp) {
		   String sentenceString = Sentence.listToString(sentence);
		   sentenceList.add(sentenceString.toString());
		}

		for (String sentence : sentenceList) {
		   System.out.println(sentence);
		   pw.write(sentence);
		   pw.write("\n");
		   System.out.println("new Sentence is :");
		}
		return sentenceList;
	}

}
