package utilities;

public class Configuration {
	//public static String ProjectPath="/home/vish/KGL/new/"; //configuraiton path on server
	public static String ProjectPath = "/home/vishwajeet/git/Ontolearn/PatternMiner/";
	public static String CorpusFile=ProjectPath+"data/merged_2000";
	public static String RuleFileName=ProjectPath+"/data/rules.txt";
	public static String Domain="NYT";
	public static String NumberOfSentences="2000";
	public static String EntityFile=ProjectPath+"data/entities.txt";
	
	
	
	
	
}
