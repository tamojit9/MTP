
package testValidity;

import miner.*;
import utilities.Configuration;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

import _stanfordParser.Document;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.parser.lexparser.LexicalizedParser;
import edu.stanford.nlp.process.CoreLabelTokenFactory;
import edu.stanford.nlp.process.PTBTokenizer;
import edu.stanford.nlp.process.Tokenizer;
import edu.stanford.nlp.process.TokenizerFactory;
import edu.stanford.nlp.trees.Tree;

public class ValidatePatterns {
	// If you do not want to use stanford parser uncomment below line
	static Document document = new Document(_stanfordParser.StanfordParserConfiguration.InputFileName);

	//static Document document = new
	 //Document(_stanfordParser.StanfordParserConfiguration.InputFileName,_stanfordParser.StanfordParserConfiguration.SerializationFileName);
	static HashMap<Integer, Integer> Thresholds;
	HashMap<String, ValidPattern> validPatterns;
	PrintWriter pw;
	double coverage;
	int ThForLengthOnePatterns;
	long totalPatterns;
	long totalInstances;
	long totalValidPatterns;
	long totalValidInstances;
	String fileNameSuffix;
	int totalSentences;
	static int maxLengthOfSentence = 300;
	static List<String> entityList; // Added by vishwajeet to all the list
	// of entities from freebase
	// static List<Integer> drop= new ArrayList<Integer>();

	public ValidatePatterns(HashMap<Integer, Integer> ThresholdMap, int totalSentences, String fileNameSuffix)
			throws FileNotFoundException {
		this.fileNameSuffix = fileNameSuffix;
		Thresholds = new HashMap<Integer, Integer>(ThresholdMap);
		this.totalSentences = totalSentences;
		totalPatterns = 0;
		totalInstances = 0;
		totalValidPatterns = 0;
		totalValidInstances = 0;
		coverage = 0.0;
		validPatterns = new HashMap<String, ValidPattern>();
		pw = new PrintWriter(MinerConfiguration.GoodInstancesFileName + fileNameSuffix);
		entityList = new ArrayList<String>();

	}

	public void validate() throws IOException {
		long start = System.currentTimeMillis();
		/*
		 * FileReader fr2 = new FileReader(MinerConfiguration.dropfile);
		 * BufferedReader br2 = new BufferedReader(fr2); String line2=""; while
		 * ((line2 = br2.readLine()) != null) { //System.out.println(line2); //
		 * drop.add(Integer.parseInt(line2)); }
		 */
		// System.out.println("speakers size inside valid
		// patterns"+document.speakers.size());
		//document.synthesizeDocument(true);

		// Use below overloaded method to just read document.

		document.synthesizeDocument();
		// System.out.println("speakers size inside valid
		// patterns"+document.speakers.size());
		readEntities();

		FileReader fr = new FileReader(MinerConfiguration.PatternTriplesFileName + fileNameSuffix);
		BufferedReader br = new BufferedReader(fr);
		String line = "";
		int ones = 0;
		// hims
		// checking of failure of code due to bad indexing
		PrintWriter errorpw = new PrintWriter(MinerConfiguration.Invalidpatterns + fileNameSuffix);

		while ((line = br.readLine()) != null) {
			totalInstances++;
			String pattern = line.substring(0, line.lastIndexOf("@") - 1);
			pattern = pattern.trim();
			line = line.substring(line.lastIndexOf("@") + 1);
			Triple triple = patternTriple(line);
			boolean includeLengthOne = (pattern.indexOf(32) == -1 && pattern.startsWith("CAT"));
			if (includeLengthOne) {
				System.out.println("including : " + pattern);
				ones++;
			}

			/*
			 * Is valid function overloading provide Triple as parameter to
			 * check triple provide pattern to check pattern
			 * 
			 */
			if(isValid(pattern))
			{
				System.out.println("valid pattern:"+pattern);
			if ((pattern.indexOf(32) != -1 && isEndingInSentence(triple)) || includeLengthOne) // errorpw

			//if ((pattern.indexOf(32) != -1 && isValid(triple,errorpw)) || includeLengthOne) // errorpw
																						// is
																						// pass
																						// to
																						// write
																						// invalid
																						// patterns
			{
				totalValidInstances++;
				ValidPattern validPatternObj = null;
				if (validPatterns.containsKey(pattern)) {
					validPatternObj = validPatterns.get(pattern);
				} else {
					validPatternObj = new ValidPattern(pattern);
					validPatterns.put(pattern, validPatternObj);
				}
				validPatternObj.occurrences.add(triple);
			}
			}
		}

		PrintWriter gift = new PrintWriter(MinerConfiguration.FrequentPatternsFilteredFileName + fileNameSuffix);

		for (String pattern : validPatterns.keySet()) {
			ValidPattern validPatternObj = validPatterns.get(pattern);
			String words[] = pattern.trim().split("\\s+");
			if (validPatternObj.occurrences.size() >= Thresholds.get(words.length)) {
				totalValidPatterns++;
				gift.write(pattern + " : ");

				String triplesString = "";
				for (Triple t : validPatternObj.occurrences) {
					triplesString += "( " + t.sentenceId + "," + t.start + "," + t.end + " ) ";
				}
				triplesString.trim();
				gift.write(triplesString + "\n");
			}
		}

		// System.out.println("Started Printing");
		writeToFile(pw);
		gift.close();
		br.close();
		fr.close();
		pw.close();

		// getCoverage(document);
		writeStats();
		long end = System.currentTimeMillis();
		System.out.println("Time taken : " + (end - start) / 1000.0 + " seconds");
		System.out.println(ones);
	}

	private void readEntities() throws IOException {
		// TODO Auto-generated method stub
		File entitiesFile = new File(Configuration.EntityFile);
		BufferedReader enbr = new BufferedReader(new FileReader(entitiesFile));
		String line = "";

		while ((line = enbr.readLine()) != null) {
			entityList.add(line);

		}
	}

	/*
	 * 
	 * To Check if a pattern ends up into a non terminal in parse tree or no
	 * just return true if you want to change validity condition
	 */
/*	public boolean isValid(Triple triple, PrintWriter errorpw) {
		
		Tree tree = (document.sentences.get(triple.sentenceId)).parseTree;
		List<Tree> leaves = tree.getLeaves();
		List<Tree> aptLeaves = tree.joinNode(leaves.get(triple.start), leaves.get(triple.end)).getLeaves();
		if (aptLeaves.size() == (triple.end - triple.start + 1))
		{
			System.out.println("true");
			return true;
		} else
		{
			return false;
		}
	}*/
	
	public boolean isEndingInSentence(Triple triple)
	{
	
		String words[] = (document.sentences.get(triple.sentenceId).text).trim().split("\\s+");
		StringBuilder phrase =new StringBuilder();
		pw.write(triple.sentenceId + " --> ");
		for (int word = triple.start; word <= triple.end; word++)
			phrase.append(words[word]+" ");

			
		final String PCG_MODEL = "edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz"; //$NON-NLS-1$
		final TokenizerFactory<CoreLabel> tokenizerFactory = PTBTokenizer.factory(new CoreLabelTokenFactory(),
				"invertible=true"); //$NON-NLS-1$
		final LexicalizedParser parser = LexicalizedParser.loadModel(PCG_MODEL);
		
		
					
		Tokenizer<CoreLabel> tokenizer = tokenizerFactory.getTokenizer(new StringReader(phrase.toString()));
		List<CoreLabel> tokens = tokenizer.tokenize();	

			Tree tree = parser.apply(tokens);
			
		for(Tree subt:tree)
		{
			System.out.println(subt.label().value());
			if(subt.label().value().equalsIgnoreCase("S"))
			{
				return true;
			}
		}
		
		


		
		System.out.println(phrase);
		return false;
		
		
	}
	

	public static boolean isValid(String pattern) throws IOException {
		int count_entity = 0;String line = "";
		if(pattern.startsWith(",")){
			return false;
		}
		String[] splitted_pattern = pattern.trim().split("\\s+");
		List<String> patternenList=new ArrayList<String>();
		patternenList=Arrays.asList(splitted_pattern);
		List<String> common=new ArrayList<String>(patternenList);

		common.retainAll(entityList);
		
      // System.out.println("pattern_in_validate_pattern"+pattern);
        System.out.println(common.size());
        if(common.size()>2)
        {
        	System.out.println(common.size());
        }
		if (common.size()>=2) {
			return true;
		} else {
			return false;
		}

		/*
		 * boolean found = false; System.out.println("I am here"); if
		 * (pattern.contains("VP")) { return true; }
		 * 
		 * return found;
		 */
	}

	public static Triple patternTriple(String pattern) {
		pattern = pattern.substring(1, pattern.length() - 1);
		int commaPosition = pattern.indexOf(",");
		int sentenceId = (Integer.parseInt(pattern.substring(0, commaPosition)));
		pattern = pattern.substring(commaPosition + 1);
		commaPosition = pattern.indexOf(",");
		int startPosition = (Integer.parseInt(pattern.substring(0, commaPosition)));
		pattern = pattern.substring(commaPosition + 1);
		int endPosition = (Integer.parseInt(pattern));

		return new Triple(sentenceId, startPosition, endPosition);
	}

	public void writeToFile(PrintWriter pw) {
		for (String pattern : validPatterns.keySet()) {
			ValidPattern validPatternObj = validPatterns.get(pattern);
			String words[] = pattern.trim().split("\\s+");
			if (validPatternObj.occurrences.size() >= Thresholds.get(words.length)) {
				validPatternObj.buildUniqueOccurrences(document);
				validPatternObj.printUniqueOccurrences(pw);
			}
		}
	}

	public void getCoverage(Document d) throws FileNotFoundException {
		boolean matrix[][] = new boolean[totalSentences + 1][maxLengthOfSentence];
		long rowWiseCoverage[][] = new long[totalSentences + 1][2];
		HashMap<String, Double> coverageMap = new HashMap<String, Double>();

		for (int i = 0; i < totalSentences; i++) {
			for (int j = 0; j < maxLengthOfSentence; j++) {
				matrix[i][j] = false;
			}
		}

		for (String pattern : validPatterns.keySet()) {
			ValidPattern validPatternObj = validPatterns.get(pattern);
			String words[] = pattern.trim().split("\\s+");
			if (validPatternObj.occurrences.size() >= Thresholds.get(words.length)) {
				for (Triple triple : validPatternObj.occurrences) {
					int row = triple.sentenceId;
					// System.out.println("The pattern was : " +
					// validPatternObj.pattern);
					// System.out.println("Sentence was : " +
					// document.sentences.get(row).text);
					for (int column = triple.start; column <= triple.end; column++) {
						matrix[row][column] = true;
						// String sentence = document.sentences.get(row).text;
						// String arr[] = sentence.trim().split("\\s+");
						// System.out.println("Word is : " + arr[column]);
					}
					// Scanner in = new Scanner(System.in);
					// int x = in.nextInt();
				}
			}
		}

		long totalWords = 0;
		long totalWordsCovered = 0;
		String notCoveredSequences = "";
		int prev = -1;

		PrintWriter pw = new PrintWriter(MinerConfiguration.CoverageStatsFileName + fileNameSuffix);
		PrintWriter pwNotCovered = new PrintWriter(MinerConfiguration.NotCoveredSentencesFileName + fileNameSuffix);
		for (int i = 1; i <= totalSentences; i++) {
			String sentence = document.speakers.get(i).text;
			String arr[] = sentence.trim().split("\\s+");
			rowWiseCoverage[i][0] = arr.length;
			rowWiseCoverage[i][1] = 0;
			notCoveredSequences = "";
			prev = -1;
			int count = 0;

			pwNotCovered.write("For Sentence Id: " + i + "\n");
			pwNotCovered.write("Sentence: " + sentence + "\n");
			pwNotCovered.write("Uncovered words/sequences : \n");

			for (int j = 0; j < rowWiseCoverage[i][0]; j++) {
				totalWords++;
				if (matrix[i][j] == true || arr[j].equals(".") || arr[j].equals(",") || arr[j].equals("(")
						|| arr[j].equals(")") || arr[j].equals("?") || arr[j].equals(";") || arr[j].equals(":")
						|| arr[j].equals("-")) {
					rowWiseCoverage[i][1]++;
					totalWordsCovered++;
				} else {
					if (prev == -1 || prev == j - 1) {
						notCoveredSequences += arr[j] + " ";
						prev = j;
					} else {
						if (notCoveredSequences.length() > 0) {
							System.out.println("sentence : " + i + " , '" + notCoveredSequences + "' is not covered.");
							pwNotCovered.write(++count + ". '" + notCoveredSequences.trim() + "' (Index : "
									+ (prev - (notCoveredSequences.trim().split("\\s+").length) + 1) + " to " + prev
									+ ")\n");
						}
						prev = j;
						notCoveredSequences = arr[j] + " ";
					}
					System.out.println("sentence : " + i + " , '" + arr[j] + j + "' is not covered.");
				}
			}

			if (notCoveredSequences.length() > 0) {
				System.out.println("sentence : " + i + " , '" + notCoveredSequences.trim() + "' is not covered.");
				pwNotCovered.write(++count + ". '" + notCoveredSequences.trim() + "' (Index : "
						+ (prev - (notCoveredSequences.trim().split("\\s+").length) + 1) + " to " + prev + ")\n");
			}

			double percent = (rowWiseCoverage[i][1] * 100.0) / rowWiseCoverage[i][0];

			pwNotCovered.write("Total Words : " + rowWiseCoverage[i][0]);
			pwNotCovered.write("\tCovered Words: " + rowWiseCoverage[i][1]);
			pwNotCovered.write("\tPercentage : " + percent + " %");
			pwNotCovered.write("\n");
			pwNotCovered.write("----------------------------------\n");

			pw.write("Sentence : " + i + "\n");
			pw.write("Total : " + rowWiseCoverage[i][0]);
			pw.write("\tCovered : " + rowWiseCoverage[i][1]);
			pw.write("\tPercentage : " + percent + " %");
			pw.write("\n");

			coverageMap.put(sentence, percent);

			// System.out.println("Sentence : " + i + " total , covered : " +
			// rowWiseCoverage[i][0] + " , "
			// + rowWiseCoverage[i][1] + " : " + percent + " %");
		}

		int buckets = 20;
		int[] frequency = new int[buckets + 1];

		Arrays.fill(frequency, 0);

		for (String s : coverageMap.keySet()) {
			double percent = coverageMap.get(s);
			int bucket = (int) (percent / (100 / buckets));
			frequency[bucket]++;
		}

		coverage = (totalWordsCovered * 100.0) / totalWords;
		pw.write("---------------------------------------------------\n");
		pw.write((totalWordsCovered * 100.0) / totalWords + "%\n");
		pw.write("Bucket Information : \n");

		for (int i = 0; i <= buckets; i++) {
			int bucketSize = 100 / buckets;

			if (i < buckets) {
				pw.write(bucketSize * i + " to " + bucketSize * (i + 1) + " : " + frequency[i] + "\n");
			} else {
				pw.write(bucketSize * i + " : " + frequency[i] + "\n");
			}
		}

		pw.close();
		pwNotCovered.close();
	}

	public void writeStats() throws IOException {
		PrintWriter out = null;
		BufferedWriter bw = null;
		FileWriter fw = null;
		fw = new FileWriter(MinerConfiguration.StatsFileName, true);
		bw = new BufferedWriter(fw);
		out = new PrintWriter(bw);

		out.print("Setting : " + fileNameSuffix + "\n");
		out.print("Total Sentences : " + totalSentences + "\n");
		out.print("Frequent Patterns from Pattern Miner : " + "------" + "\n");
		out.print("Valid Frequent Patterns (post validity checking) : " + totalValidPatterns + "\n");
		out.print("Frequent Instances from Pattern Miner : " + totalInstances + "\n");
		out.print("Valid Frequent Instances (post validity checking) : " + totalValidInstances);
		out.format("(%.2f%%)\n", (totalValidInstances * 100.0) / totalInstances);
		out.format("Coverage : %.2f%%\n", coverage);
		out.println("***********************************************************");

		out.close();
		bw.close();
		fw.close();
	}
}