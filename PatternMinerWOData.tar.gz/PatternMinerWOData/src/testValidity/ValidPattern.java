

package testValidity;

import miner.*;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import _stanfordParser.Document;

public class ValidPattern
{
	String pattern;
	List<Triple> occurrences;
	HashMap<String, List<Triple>> uniqueInstances;

	public ValidPattern(String pattern)
	{
		this.pattern = pattern;
		occurrences = new ArrayList<Triple>();
		uniqueInstances = new HashMap<String, List<Triple>>();
	}

	public void printOccurrences(Document document, PrintWriter pw)
	{
		pw.write(pattern + " : " + occurrences.size() + " : " + "\n");
		for (Triple triple : occurrences)
		{
			String words[] = (document.sentences.get(triple.sentenceId).text).trim().split("\\s+");
			pw.write(triple.sentenceId + " --> ");
			for (int word = triple.start; word <= triple.end; word++)
				pw.write(words[word] + " ");

			pw.write("\n");
		}
		pw.write("*************************************************\n");
	}

	public void printUniqueOccurrences(PrintWriter pw)
	{
		pw.write("Pattern : " + pattern + " ; Total occurences = " + occurrences.size()
				+ " ; The various instances are :" + "\n");
		for (String instance : uniqueInstances.keySet())
		{
			List<Triple> instanceList = uniqueInstances.get(instance);
			pw.write("Instance : " + instance + "( Total Occurrences = " + instanceList.size() + " ) : " + "\n");
			pw.write("Sentence IDs : ");
			for (Triple triple : instanceList)
			{
				pw.write(triple.sentenceId + ", ");
			}
			pw.write("\n----------------------------------------------------------\n");
		}
		pw.write("*************************************************\n");
	}

	public void buildUniqueOccurrences(Document document)
	{
		for (Triple triple : occurrences)
		{
			//System.out.println(triple); //vishwajeet added to check triples are set
			String instance = "";
			//System.out.println(document.sentences.size());
			String words[] = (document.sentences.get(triple.sentenceId).text).trim().split("\\s+");
			//System.out.println(triple.sentenceId+"     "+triple.start+"   "+triple.end+"     "+words.length+"\n");
			
			for (int word = triple.start; word <= triple.end; word++)
				instance += (words[word] + " ");

			if (uniqueInstances.containsKey(instance))
			{
				uniqueInstances.get(instance).add(triple);
			} else
			{
				List<Triple> instanceList = new ArrayList<Triple>();
				instanceList.add(triple);
				uniqueInstances.put(instance, instanceList);
			}
		}
	}
}