

package cleaning;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import _stanfordParser.StanfordParserConfiguration;

public class RemoveFW
{
	static HashMap<String, Integer> toPrint = new HashMap<String, Integer>();

	public static void remove() throws IOException
	{
		PrintWriter pw = new PrintWriter(CleaningConfiguration.outputFilePath);
		ArrayList<String> dt = putInArray(CleaningConfiguration.dictionariesPath + "articles.txt");
		ArrayList<String> cc = putInArray(CleaningConfiguration.dictionariesPath + "conjunctions.txt");
		ArrayList<String> prep = putInArray(CleaningConfiguration.dictionariesPath + "prepositions.txt");
		System.out.println(dt.size() + " " + cc.size() + " " + prep.size());
		System.out.println("Removed dt : " + removeFunctionalWords(dt, true, pw));
		System.out.println("Removed cc : " + removeFunctionalWords(cc, false, pw));
		System.out.println("Removed prepositions : " + removeFunctionalWords(prep, false, pw));
		for (String s : toPrint.keySet())
		{
			if(s.split(" ").length>8)
				continue;
			if (toPrint.get(s) == 3)
			{
				pw.write(s + "\n");
			}
		}
		pw.close();
	}

	public static ArrayList<String> putInArray(String fileName) throws IOException
	{
		ArrayList<String> wordsList = new ArrayList<String>();
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		String line = "";
		while ((line = br.readLine()) != null)
		{
			wordsList.add(line.toLowerCase());
		}
		br.close();
		fr.close();
		return wordsList;
	}

	public static long removeFunctionalWords(ArrayList<String> wordsList, boolean removeOnlyIfLengthOne, PrintWriter pw)
			throws IOException
	{
		String fileName = CleaningConfiguration.inputFilePath;
		long removed = 0;
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		String line = "";
		while ((line = br.readLine()) != null)
		{
			line = line.substring((StanfordParserConfiguration.PhraseType + " -> ").length());
			String lineCopy = line;
			line = line.toLowerCase();
			boolean print = true;
			String words[] = line.split(" ");

			if (wordsList.contains(words[0]))
			{
				if (removeOnlyIfLengthOne)
				{
					if (words.length == 1)
					{
						print = false;
					}
				} else
				{
					print = false;
				}
			}
			if (wordsList.contains(words[words.length - 1]))
			{
				if (!removeOnlyIfLengthOne)
					print = false;
			}
			if (!print)
			{
				System.out.println("Removed : " + line);
				removed++;
			} else
			{
				lineCopy = lineCopy.replace("-LRB-", "(");
				lineCopy = lineCopy.replace("-RRB-", ")");
				String key = "NP -> " + lineCopy;
				if (toPrint.containsKey(key))
				{
					int val = toPrint.get(key);
					toPrint.put(key, val + 1);
				} else
				{
					toPrint.put(key, 1);
				}
			}

		}
		br.close();
		fr.close();
		return removed;
	}
}