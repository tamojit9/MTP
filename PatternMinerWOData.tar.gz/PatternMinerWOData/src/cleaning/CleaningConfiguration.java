

package cleaning;

import _stanfordParser.StanfordParserConfiguration;
import utilities.Configuration;

public class CleaningConfiguration
{
	public static String ProjectPath = Configuration.ProjectPath;
	
	static String dictionariesPath = ProjectPath + "data/cleaning/input/dictionaries/";
	static String inputFilePath = ProjectPath + "data/cleaning/input/miner_input.txt";
	static String outputFilePath = ProjectPath + "data/cleaning/output/cleaned_miner_input.txt";
}