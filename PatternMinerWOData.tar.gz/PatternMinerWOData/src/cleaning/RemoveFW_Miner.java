

package cleaning;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;

import _stanfordParser.StanfordParserConfiguration;
import edu.stanford.nlp.ling.tokensregex.PhraseTable.WordList;

import utilities.Configuration;

public class RemoveFW_Miner
{
	static HashMap<String, Integer> toPrint = new HashMap<String, Integer>();

	public static void remove() throws IOException
	{
		PrintWriter pw = new PrintWriter(CleaningConfiguration.outputFilePath);
		ArrayList<String> dt = putInArray(CleaningConfiguration.dictionariesPath + "articles.txt");
		ArrayList<String> cc = putInArray(CleaningConfiguration.dictionariesPath + "conjunctions.txt");
		ArrayList<String> prep = putInArray(CleaningConfiguration.dictionariesPath + "prepositions.txt");
		ArrayList<String> sw = putInArray(CleaningConfiguration.dictionariesPath+"stopwords_en.txt");
		ArrayList<String> final_list = new ArrayList<String>();
		final_list.addAll(dt);
		final_list.addAll(cc);
		final_list.addAll(prep);
		final_list.addAll(sw);
		System.out.println(dt.size() + " " + cc.size() + " " + prep.size()+" "+sw.size());
		System.out.println("Removed dt : " + removeFunctionalWords(final_list,pw));
		/*System.out.println("Removed cc : " + removeFunctionalWords(cc, false, pw));
		System.out.println("Removed cc : " + removeFunctionalWords(sw, false, pw));
		System.out.println("Removed prepositions : " + removeFunctionalWords(prep, false, pw));*/
		for (String s : toPrint.keySet())
		{
			if(s.split(" ").length>8)
				continue;
			if (toPrint.get(s) == 3)
			{
				pw.write(s + "\n");
			}
		}
		pw.close();
	}

	public static ArrayList<String> putInArray(String fileName) throws IOException
	{
		ArrayList<String> wordsList = new ArrayList<String>();
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		String line = "";
		while ((line = br.readLine()) != null)
		{
			wordsList.add(line.toLowerCase());
		}
		br.close();
		fr.close();
		return wordsList;
	}

	public static long removeFunctionalWords(ArrayList<String> wordsList, PrintWriter pw)
			throws IOException
	{
		String fileName = CleaningConfiguration.inputFilePath;
		long removed = 0;
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		String line = "";
		while ((line = br.readLine()) != null)
		{
			//line = line.substring(3);
			System.out.println("line:"+line);
			String lineCopy = line;
			line = line.toLowerCase();
			boolean print = true;
			String words[] = line.split(" ");
			for(String word:words)
			{
				if(wordsList.contains(word))
				{
					System.out.println(word);
					System.out.println("line is"+line);
					words=(String[]) ArrayUtils.removeElement(words,word);
				}
					
			}
			StringBuilder builder = new StringBuilder();
			for(String s : words) {
			    builder.append(s);
			    builder.append(" ");
			}
			String final_output= builder.toString().trim();
			System.out.println(final_output);
          pw.write(final_output);
			
		}
		br.close();
		fr.close();
		return removed;
	}
	public static void main(String args[]) throws IOException
	{
		remove();
	}
}